package com.example.kartik_portfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
